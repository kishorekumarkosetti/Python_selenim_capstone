from selenium.webdriver.common.by import By
from pages.base_page import BasePage
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class VerifyProductQuantityPage(BasePage):
    def _init_(self, driver):
        self.driver = driver

    view_product_button = (By.XPATH, "//a[contains(text(), 'View Product')]")
    quantity_input = (By.ID, "quantity")
    add_to_cart_button = (By.XPATH, '/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button')
    view_cart_in_popup = (By.XPATH, "//*[@id='cartModal']/div/div/div[2]/p[2]/a/u")
    cart_quantity = (By.XPATH, '//*[@id="product-1"]/td[4]/button')


    def click_view_product(self):
        self.driver.find_element(*self.view_product_button).click()

    def is_element_visible(self, locator):
        elements = self.driver.find_elements(*locator)
        return len(elements) > 0

    def increase_quantity(self, quantity):
        element = self.driver.find_element(*self.quantity_input)
        element.clear()
        element.send_keys(str(quantity))
        time.sleep(1) 

    def add_to_cart(self):
        self.driver.find_element(*self.add_to_cart_button).click()
        time.sleep(2)  

    def click_view_cart_in_popup(self):
        self.driver.find_element(*self.view_cart_in_popup).click()
        time.sleep(2)  

    def get_quantity_in_cart(self):
        try:
            element = self.driver.find_element(*self.cart_quantity)
            return element.get_attribute("value")
        except Exception as e:
            print(f"Error getting quantity from cart: {e}")
            return None

    def get_quantity_in_cart(self):
        try:
            element = WebDriverWait(self.driver, 20).until(
                EC.visibility_of_element_located(self.cart_quantity)
            )
            quantity_value = element.get_attribute("value")  
            if not quantity_value: 
                quantity_value = element.text
            return quantity_value
        except Exception as e:
            print(f"Error getting quantity from cart: {e}")
            return None