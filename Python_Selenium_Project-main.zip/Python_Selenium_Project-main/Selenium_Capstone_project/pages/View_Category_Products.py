from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class CategoryProductsPage(BasePage):
    CATEGORIES_SECTION = (By.XPATH, "//div[@class='left-sidebar']")
    WOMEN_CATEGORY = (By.XPATH, "//a[normalize-space()='Women']")
    WOMEN_CATEGORY_DRESS = (By.XPATH, "//div[@id='Women']//a[contains(text(),'Dress')]")
    CATEGORY_PAGE_HEADER = (By.XPATH, "//h2[normalize-space()='Women - Dress Products']")
    MEN_CATEGORY = (By.XPATH, "//a[normalize-space()='Men']")
    MEN_SUBCATEGORY = (By.XPATH, "//a[normalize-space()='Tshirts']")
    MEN_CATEGORY_PAGE_HEADER = (By.XPATH, "//h2[normalize-space()='Men - Tshirts Products']")

    def _init_(self, driver):
        super()._init_(driver)

    def verify_categories_visible(self):
        is_visible = self.is_element_visible(self.CATEGORIES_SECTION)
        print(f"Categories visible: {is_visible}")
        return is_visible

    def click_women_category(self):
        self.scroll_to_element(self.WOMEN_CATEGORY)
        self.wait_for_element_to_be_clickable(self.WOMEN_CATEGORY)
        print("Clicking Women category")
        self.click(self.WOMEN_CATEGORY)

    def click_women_category_dress(self):
        self.scroll_to_element(self.WOMEN_CATEGORY_DRESS)
        self.wait_for_element_to_be_clickable(self.WOMEN_CATEGORY_DRESS)
        print("Clicking Women category Dress")
        self.click(self.WOMEN_CATEGORY_DRESS)

    def verify_category_page_displayed(self):
        is_visible = self.is_element_visible(self.CATEGORY_PAGE_HEADER)
        print(f"Women Dress category page visible: {is_visible}")
        return is_visible

    def click_men_category(self):
        self.scroll_to_element(self.MEN_CATEGORY)
        self.wait_for_element_to_be_clickable(self.MEN_CATEGORY)
        print("Clicking Men category")
        self.click(self.MEN_CATEGORY)

    def click_men_subcategory(self):
        self.scroll_to_element(self.MEN_SUBCATEGORY)
        self.wait_for_element_to_be_clickable(self.MEN_SUBCATEGORY)
        print("Clicking Men subcategory")
        self.click(self.MEN_SUBCATEGORY)

    def verify_men_category_page_displayed(self):
        is_visible = self.is_element_visible(self.MEN_CATEGORY_PAGE_HEADER)
        print(f"Men T-shirt category page visible: {is_visible}")
        return is_visible

    def wait_for_element_to_be_clickable(self, locator, timeout=10):
        print(f"Waiting for element to be clickable: {locator}")
        WebDriverWait(self.driver, timeout).until(EC.element_to_be_clickable(locator))

    def scroll_to_element(self, locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        print(f"Scrolled to element: {locator}")