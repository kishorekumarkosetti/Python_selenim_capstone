from pages.base_page import BasePage 
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from config.config import *
import time


class RemoveProduct(BasePage):
    
    PRODUCT_LOCATOR = (By.XPATH, "//a[@href='/product_details/1']") 
    ADD_TO_CART_LOCATOR = (By.XPATH, '/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button')  
    CART_LOCATOR = (By.XPATH, "//a[@href='/view_cart']")  
    VIEW_CART_LOCATOR = (By.XPATH, '//*[@id="cartModal"]/div/div/div[2]/p[2]/a/u') 
    CROSS_MARK = (By.XPATH , "//tr[@id='product-1']//i[@class='fa fa-times']")
    
    def add_product_to_cart(self):
            self.wait_for_element_to_be_clickable(self.PRODUCT_LOCATOR)
            self.do_click(self.PRODUCT_LOCATOR)

            self.wait_for_element_to_be_clickable(self.ADD_TO_CART_LOCATOR)
            self.do_click(self.ADD_TO_CART_LOCATOR)

            self.wait_for_element_to_be_clickable(self.VIEW_CART_LOCATOR)
            self.do_click(self.VIEW_CART_LOCATOR)

    def go_to_cart(self):
        self.wait_for_element_to_be_clickable(self.CART_LOCATOR)
        self.do_click(self.CART_LOCATOR) 
        
    def remove_product(self):
        self.do_click(self.CROSS_MARK)
        time.sleep(2) 
        print("Product Removed successfully")

    def wait_for_element_to_be_visible(self, locator, timeout=10):
        WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(locator))

    def wait_for_element_to_be_clickable(self, locator, timeout=10):
        WebDriverWait(self.driver, timeout).until(EC.element_to_be_clickable(locator))














