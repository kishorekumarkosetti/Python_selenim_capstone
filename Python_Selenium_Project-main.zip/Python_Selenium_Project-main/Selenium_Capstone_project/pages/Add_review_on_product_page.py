from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class AddReviewPage(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    ALL_PRODUCTS_HEADER = (By.XPATH, "//h2[normalize-space()='All Products']")
    VIEW_PRODUCT_BUTTON = (By.XPATH, "//div[2]//div[1]//div[2]//ul[1]//li[1]//a[1]")
    WRITE_YOUR_REVIEW_HEADER = (By.XPATH, "//a[normalize-space()='Write Your Review']")
    REVIEW_NAME_INPUT = (By.XPATH, "//input[@id='name']")
    REVIEW_EMAIL_INPUT = (By.XPATH, "//input[@id='email']")
    REVIEW_TEXTAREA = (By.XPATH, "//textarea[@id='review']")
    SUBMIT_BUTTON = (By.XPATH, "//button[@id='button-review']")
    SUCCESS_MESSAGE = (By.XPATH, "//span[contains(text(),'Thank you for your review.')]")

    def _init_(self, driver):
        super()._init_(driver)

    def click_products_button(self):
        self.click(self.PRODUCTS_BUTTON)

    def verify_all_products_page(self):
        return self.is_element_visible(self.ALL_PRODUCTS_HEADER)

    def click_view_product(self):
        element = self.driver.find_element(*self.VIEW_PRODUCT_BUTTON)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.VIEW_PRODUCT_BUTTON))
        self.click(self.VIEW_PRODUCT_BUTTON)

    def verify_write_review_visible(self):
        return self.is_element_visible(self.WRITE_YOUR_REVIEW_HEADER)

    def enter_review_details(self, name, email, review):
        self.enter_text(self.REVIEW_NAME_INPUT, name)
        self.enter_text(self.REVIEW_EMAIL_INPUT, email)
        self.enter_text(self.REVIEW_TEXTAREA, review)

    def click_submit_button(self):
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.SUBMIT_BUTTON))
        self.click(self.SUBMIT_BUTTON)

    def verify_success_message(self):
        return self.is_element_visible(self.SUCCESS_MESSAGE)