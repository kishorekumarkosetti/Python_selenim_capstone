from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage

class ScrollPage(BasePage):
    SUBSCRIPTION_SECTION = (By.XPATH, "//h2[normalize-space()='Subscription']")
    ARROW_BUTTON = (By.XPATH, "//button[@id='subscribe']")
    PRACTICE_WEBSITE_TEXT = (By.XPATH, "//div[@class='item active']//h2[contains(text(),'Full-Fledged practice website for Automation Engineers')]")

    def verify_home_page(self):
        """Verify that home page is visible successfully."""
        assert "Automation Exercise" in self.driver.title

    def scroll_down_to_bottom(self):
        """Scroll down the page to the bottom."""
        self.driver.find_element(By.TAG_NAME, 'body').send_keys(Keys.END)

    def verify_subscription_visible(self):
        """Verify 'SUBSCRIPTION' is visible."""
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.SUBSCRIPTION_SECTION)
        )

    def click_arrow_button(self):
        """Click on arrow at bottom right side to move upward."""
        self.click(self.ARROW_BUTTON)

    def verify_practice_website_text_visible(self):
        """Verify 'Full-Fledged practice website for Automation Engineers' text is visible on screen."""
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.PRACTICE_WEBSITE_TEXT)
        )