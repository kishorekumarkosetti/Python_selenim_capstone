from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class SignUpPage(BasePage):
    # Locators for signup form
    NAME_LOCATOR = (By.NAME, "name")
    EMAIL_LOCATOR = (By.XPATH, "//input[@data-qa='signup-email']")
    SIGNUP_BUTTON_LOCATOR = (By.XPATH, "//button[text()='Signup']")

    # Locators for account information
    TITLE_LOCATOR = (By.NAME, "title")
    PASSWORD_LOCATOR = (By.NAME, "password")
    DAY_LOCATOR = (By.NAME, "days")
    MONTH_LOCATOR = (By.NAME, "months")
    YEAR_LOCATOR = (By.NAME, "years")

    # Locators for address details
    FIRST_NAME_LOCATOR = (By.NAME, "first_name")
    LAST_NAME_LOCATOR = (By.NAME, "last_name")
    COMPANY_LOCATOR = (By.NAME, "company")
    ADDRESS_LOCATOR = (By.NAME, "address1")
    CITY_LOCATOR = (By.NAME, "city")
    STATE_LOCATOR = (By.NAME, "state")
    ZIPCODE_LOCATOR = (By.NAME, "zipcode")
    MOBILE_NUMBER_LOCATOR = (By.NAME, "mobile_number")

    # Buttons
    CREATE_ACCOUNT_BUTTON_LOCATOR = (By.XPATH, "//button[text()='Create Account']")
    CONTINUE_BUTTON_LOCATOR = (By.XPATH, "//a[@data-qa='continue-button']")
    IS_LOGGED_IN_LOCATOR = (By.XPATH, "//li/a[contains(text(), 'Logged in as')]/b")
    DELETE_ACCOUNT_BUTTON_LOCATOR = (By.XPATH, "//a[contains(text(), 'Delete Account')]")
    
    NEW_USER_SIGNUP_LOCATOR = (By.XPATH, "//h2[text()='New User Signup!']")
    EMAIL_EXISTS_ERROR_LOCATOR = (By.XPATH, "//p[text()='Email Address already exist!']")
    
    def enter_signup_details(self, name, email):
        self.enter_text(self.NAME_LOCATOR, name)
        self.enter_text(self.EMAIL_LOCATOR, email)
        self.click(self.SIGNUP_BUTTON_LOCATOR)

    def enter_account_information(self, title, password, day, month, year):
        self.click(self.TITLE_LOCATOR)
        self.enter_text(self.PASSWORD_LOCATOR, password)
        self.select_option(self.DAY_LOCATOR, day)
        self.select_option(self.MONTH_LOCATOR, month)
        self.select_option(self.YEAR_LOCATOR, year)

    def enter_address_details(self, first_name, last_name, company, address, city, state, zipcode, mobile):
        self.enter_text(self.FIRST_NAME_LOCATOR, first_name)
        self.enter_text(self.LAST_NAME_LOCATOR, last_name)
        self.enter_text(self.COMPANY_LOCATOR, company)
        self.enter_text(self.ADDRESS_LOCATOR, address)
        self.enter_text(self.CITY_LOCATOR, city)
        self.enter_text(self.STATE_LOCATOR, state)
        self.enter_text(self.ZIPCODE_LOCATOR, zipcode)
        self.enter_text(self.MOBILE_NUMBER_LOCATOR, mobile)

    def click_create_account(self):
        self.click(self.CREATE_ACCOUNT_BUTTON_LOCATOR)

    def click_continue(self):
        self.click(self.CONTINUE_BUTTON_LOCATOR)

    def is_logged_in_as(self):
        return self.is_element_visible(self.IS_LOGGED_IN_LOCATOR)

    def click_delete_account(self):
        self.click(self.DELETE_ACCOUNT_BUTTON_LOCATOR)
        
    def is_new_user_signup_visible(self):
        return self.is_element_visible(self.NEW_USER_SIGNUP_LOCATOR)
    
    def click_signup(self):
        self.click(self.SIGNUP_BUTTON_LOCATOR)
        
    def is_email_exists_error_visible(self):
        return self.is_element_visible(self.EMAIL_EXISTS_ERROR_LOCATOR)
    
    
