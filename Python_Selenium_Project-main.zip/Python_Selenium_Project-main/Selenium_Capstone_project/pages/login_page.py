from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class LoginPage(BasePage):
    EMAIL_LOCATOR = (By.NAME, "email")
    PASSWORD_LOCATOR = (By.NAME, "password")
    LOGIN_BUTTON_LOCATOR = (By.XPATH, "//button[text()='Login']")
    IS_LOGGED_IN_LOCATOR = (By.XPATH, "//li/a[contains(text(), 'Logged in as')]")
    ERROR_MESSAGE_LOCATOR = (By.XPATH, "//p[contains(text(), 'Your email or password is incorrect!')]")
    LOGOUT_BUTTON_LOCATOR = (By.XPATH, "//li/a[contains(text(), 'Logout')]")
    LOGIN_PAGE_LOCATOR = (By.XPATH, "//h2[text()='Login to your account']")
    
    def enter_login_details(self, email, password):
        self.enter_text(self.EMAIL_LOCATOR, email)
        self.enter_text(self.PASSWORD_LOCATOR, password)
    
    def click_login(self):
        self.click(self.LOGIN_BUTTON_LOCATOR)
        
    def is_logged_in_as(self):
        try:
            return self.is_element_visible(self.IS_LOGGED_IN_LOCATOR)
        except Exception as e:
            print(f"An error occurred while checking the login status: {e}")
            return False

    def is_error_message_displayed(self):
        try:
            return self.is_element_visible(self.ERROR_MESSAGE_LOCATOR)
        except Exception as e:
            print(f"An error occurred while checking the error message: {e}")
            return False

    def click_logout(self):
        self.click(self.LOGOUT_BUTTON_LOCATOR)

    def is_login_page_visible(self):
        try:
            return self.is_element_visible(self.LOGIN_PAGE_LOCATOR)
        except Exception as e:
            print(f"An error occurred while checking the login page visibility: {e}")
            return False
        
  
