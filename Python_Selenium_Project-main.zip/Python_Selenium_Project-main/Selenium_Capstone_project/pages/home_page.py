from pages.base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class HomePage(BasePage):
    SIGNUP_LOGIN_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/login']")
    CONTACT_US_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/contact_us']")
    HOME_PAGE_LOCATOR = (By.XPATH, "//a[@href='/']")
    PRODUCTS_BUTTON = (By.XPATH, "//*[@id='header']/div/div/div/div[2]/div/ul/li[2]/a")

    def click_signup_login(self):
        self.click(self.SIGNUP_LOGIN_BUTTON_LOCATOR)
        
    def click_contact_us(self):
        self.click(self.CONTACT_US_BUTTON_LOCATOR)
        
    def is_home_page_visible(self):
        return self.is_element_visible(self.HOME_PAGE_LOCATOR)
    
    def click_products(self):
        products_button_element = WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.PRODUCTS_BUTTON)
        )
        products_button_element.click()





"""from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage"""


"""
class HomePage(BasePage):
    SIGNUP_LOGIN_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/login']")
    CONTACT_US_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/contact_us']")
    HOME_PAGE_LOCATOR = (By.XPATH, "//a[@href='/']")
    PRODUCTS_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/products']")
    ADD_TO_CART_BUTTON_LOCATOR = (By.XPATH, "(//a[contains(text(), 'Add to cart')])[1]")  # First product
    CART_BUTTON_LOCATOR = (By.XPATH, "//*[@id='cartModal']/div/div/div[2]/p[2]/a/u")"""
""""
    def click_signup_login(self):
        self.click(self.SIGNUP_LOGIN_BUTTON_LOCATOR)

    def click_contact_us(self):
        self.click(self.CONTACT_US_BUTTON_LOCATOR)

    def click_products(self):
        self.click(self.PRODUCTS_BUTTON_LOCATOR)

    def is_home_page_visible(self):
        return self.is_element_visible(self.HOME_PAGE_LOCATOR)

    def add_first_product_to_cart(self):
     
        self.click(self.ADD_TO_CART_BUTTON_LOCATOR)

    def click_cart_button(self):
        self.close_popup_if_present()

        # Wait until the cart button is clickable
        cart_button = WebDriverWait(self.driver, 5).until(
            EC.element_to_be_clickable(self.CART_BUTTON_LOCATOR)
        )
        self.scroll_to_element(cart_button)
        cart_button.click()

    def close_popup_if_present(self):
        try:
            overlay_locator = (By.XPATH, "//div[@class='overlay']")  # Replace with the actual locator
            if self.is_element_visible(overlay_locator):
                self.click(overlay_locator)
        except Exception as e:
            print(f"No popup to handle or failed to close popup: {e}") """

""""
class HomePage(BasePage):
    # Existing locators...
    SEARCH_BAR_LOCATOR = (By.XPATH, "//input[@type='text' and @name='search']")
    SEARCH_BUTTON_LOCATOR = (By.XPATH, "//button[contains(text(), 'Search')]")
    BANNER_LOCATOR = (By.XPATH, "//div[@class='banner']")
    CART_ICON_LOCATOR = (By.XPATH, "//div[@class='cart-icon']")
    LOGO_LOCATOR = (By.XPATH, "//img[@alt='Website Logo']")
    PRODUCTS_BUTTON = (By.XPATH, "//*[@id='header']/div/div/div/div[2]/div/ul/li[2]/a")
    WOMEN_CATEGORY_LOCATOR = (By.XPATH, "//a[contains(text(), 'Women')]")
    MEN_CATEGORY_LOCATOR = (By.XPATH, "//a[contains(text(), 'Men')]")
    DRESS_SUBCATEGORY_LOCATOR = (By.XPATH, "//a[contains(text(), 'Dress')]")
    CATEGORY_PAGE_HEADER_LOCATOR = (By.XPATH, "//h2[contains(text(), 'WOMEN - DRESS PRODUCTS')]")  # Assuming it's visible for 'Dress'
    MEN_SUBCATEGORY_LOCATOR = (By.XPATH, "//div[@class='left-sidebar']//a[contains(text(), 'Men')]")
    
    # Method to perform a search
    def search_for_item(self, search_term):
        self.type(self.SEARCH_BAR_LOCATOR, search_term)
        self.click(self.SEARCH_BUTTON_LOCATOR)

    # Method to verify the homepage banner is displayed
    def verify_homepage_banner(self):
        return self.is_element_visible(self.BANNER_LOCATOR)
    
    # Method to navigate to the shopping cart
    def go_to_cart(self):
        self.click(self.CART_ICON_LOCATOR)

    # Method to verify if the logo is visible on the homepage
    def is_logo_visible(self):
        return self.is_element_visible(self.LOGO_LOCATOR)

    # Method to verify if the search bar is visible
    def is_search_bar_visible(self):
        return self.is_element_visible(self.SEARCH_BAR_LOCATOR)
    
    # Method to check if 'Women' category is visible in the header (for direct navigation)
    def is_women_category_visible_in_header(self):
        return self.is_element_visible(self.WOMEN_CATEGORY_LOCATOR)
    
    # Method to check if 'Men' category is visible in the header (for direct navigation)
    def is_men_category_visible_in_header(self):
        return self.is_element_visible(self.MEN_CATEGORY_LOCATOR)
    
    # Method to navigate to 'Women' category directly from the header
    def navigate_to_women_category(self):
        self.click(self.WOMEN_CATEGORY_LOCATOR)
    
    # Method to navigate to 'Men' category directly from the header
    def navigate_to_men_category(self):
        self.click(self.MEN_CATEGORY_LOCATOR)
    
    # Method to verify if 'Men' subcategory is visible in the left sidebar
    def is_men_subcategory_visible_in_sidebar(self):
        return self.is_element_visible(self.MEN_SUBCATEGORY_LOCATOR)
    
    def click_products_button(self):

        self.click(self.PRODUCTS_BUTTON)"""

