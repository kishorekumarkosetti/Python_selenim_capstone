from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class RecommendedItemsPage(BasePage):
    RECOMMENDED_ITEMS_SECTION = (By.XPATH, "//h2[normalize-space()='recommended items']")
    ADD_TO_CART_RECOMMENDED_ITEM = (By.XPATH, "//body[1]/section[2]/div[1]/div[1]/div[2]/div[1]/div[35]/div[1]/div[1]/div[1]/a[1]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    CART_PRODUCT = (By.XPATH, "//td[@class='cart_description']//h4//a")

    def _init_(self, driver):
        super()._init_(driver)

    def scroll_to_recommended_items(self):
        recommended_items_section = self.driver.find_element(*self.RECOMMENDED_ITEMS_SECTION)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", recommended_items_section)
        print("Scrolled to 'RECOMMENDED ITEMS' section")

    def verify_recommended_items_visible(self):
        is_visible = self.is_element_visible(self.RECOMMENDED_ITEMS_SECTION)
        print(f"'RECOMMENDED ITEMS' visibility: {is_visible}")
        return is_visible

    def add_recommended_item_to_cart(self):
        element = self.driver.find_element(*self.ADD_TO_CART_RECOMMENDED_ITEM)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.ADD_TO_CART_RECOMMENDED_ITEM))
        self.click(self.ADD_TO_CART_RECOMMENDED_ITEM)
        print("'Add to Cart' button clicked for recommended item")

    def click_view_cart_button(self):
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.VIEW_CART_BUTTON))
        self.click(self.VIEW_CART_BUTTON)
        print("'View Cart' button clicked")

    def verify_product_in_cart(self):
        is_visible = self.is_element_visible(self.CART_PRODUCT)
        print(f"Product visibility in cart: {is_visible}")
        return is_visible
        