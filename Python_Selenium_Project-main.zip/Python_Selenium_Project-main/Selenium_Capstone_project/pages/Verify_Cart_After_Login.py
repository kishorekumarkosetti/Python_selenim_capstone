from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage

class SearchAndCartPage(BasePage):
    # Locators
    products_button = (By.XPATH, "//a[contains(text(), 'Products')]")
    all_products_page = (By.XPATH, "//h2[text()='All Products']")
    search_input = (By.XPATH, "//input[@id='search_product']")
    search_button = (By.XPATH, "//button[@id='submit_search']")
    searched_products = (By.XPATH, "//h2[text()='Searched Products']")
    search_results = (By.XPATH, "//div[@class='productinfo text-center']")
    add_to_cart_buttons = (By.XPATH, "//a[contains(text(), 'Add to cart')]")
    cart_button = (By.XPATH, "//a[@href='/view_cart']")
    cart_products = (By.XPATH, "//td[@class='cart_description']")
    login_signup_button = (By.XPATH, "//a[contains(text(), 'Signup / Login')]")
    email_input = (By.XPATH, "//input[@name='email']")
    password_input = (By.XPATH, "//input[@name='password']")
    login_submit_button = (By.XPATH, "//button[@type='submit']")
    empty_cart_message = (By.XPATH, "//b[normalize-space()='Cart is empty!']")
    remove_product_buttons = (By.XPATH, "//a[@class='cart_quantity_delete']")
    add_to_cart_buttons = (By.XPATH, "//a[contains(text(), 'Add to cart')]")
    view_cart_popup_button = (By.XPATH, "//u[normalize-space()='View Cart']")

    def add_search_results_to_cart_and_view_cart(self):
        add_buttons = WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.add_to_cart_buttons)
        )
        for button in add_buttons:
            button.click()
            # Wait for the 'View Cart' popup and click the button
            view_cart_button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable(self.view_cart_popup_button)
            )
            view_cart_button.click()
            break  # Exit the loop after handling the first popup
        
    def click_products_button(self):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.products_button)
        ).click()

    def verify_all_products_page(self):
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.all_products_page)
        )

    def search_for_product(self, search_term):
        search_field = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.search_input)
        )
        search_field.clear()
        search_field.send_keys(search_term)
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.search_button)
        ).click()

    def verify_searched_products_visible(self):
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.searched_products)
        )

    def verify_search_results(self):
        return WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.search_results)
        )

    def add_search_results_to_cart(self):
        add_buttons = WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.add_to_cart_buttons)
        )
        for button in add_buttons:
            button.click()

    def go_to_cart(self):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.cart_button)
        ).click()

    def verify_products_in_cart(self):
        return WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.cart_products)
        )

    def click_login_signup(self):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.login_signup_button)
        ).click()

    def enter_login_details(self, email, password):
        email_field = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.email_input)
        )
        email_field.clear()
        email_field.send_keys(email)

        password_field = self.driver.find_element(*self.password_input)
        password_field.clear()
        password_field.send_keys(password)

    def submit_login(self):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.login_submit_button)
        ).click()

    def remove_all_products_from_cart(self):
        while True:
            try:
                remove_buttons = WebDriverWait(self.driver, 5).until(
                    EC.presence_of_all_elements_located(self.remove_product_buttons)
                )
                for button in remove_buttons:
                    button.click()
            except:
                break

    def verify_cart_empty(self):
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.empty_cart_message)
            )