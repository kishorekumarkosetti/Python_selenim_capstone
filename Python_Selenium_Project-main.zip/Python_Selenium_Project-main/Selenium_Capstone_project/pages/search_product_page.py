from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class ProductsPage(BasePage):
    ALL_PRODUCTS_HEADER = (By.XPATH, "//h2[text()='All Products']")
    SEARCH_INPUT = (By.ID, "search_product")
    SEARCH_BUTTON = (By.ID, "submit_search")
    SEARCHED_PRODUCTS_HEADER = (By.XPATH, "//h2[text()='Searched Products']")
    SEARCHED_PRODUCTS_LIST = (By.XPATH , "//div[@class='product-overlay']")

    def is_all_products_header_visible(self):
        return self.is_element_visible(self.ALL_PRODUCTS_HEADER)

    def search_product(self, product_name):
        self.do_send_keys(self.SEARCH_INPUT, product_name)
        self.do_click(self.SEARCH_BUTTON)

    def is_searched_products_header_visible(self):
        return self.is_element_visible(self.SEARCHED_PRODUCTS_HEADER)

    def get_searched_products_count(self):
        return len(self.get_elements(self.SEARCHED_PRODUCTS_LIST))







