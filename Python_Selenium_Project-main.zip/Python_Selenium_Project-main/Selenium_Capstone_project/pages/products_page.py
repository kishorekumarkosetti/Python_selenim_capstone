from pages.base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class ProductsPage(BasePage):
    PRODUCTS_HEADER = (By.XPATH, "//h2[text()='All Products']")
    SEARCH_INPUT = (By.ID, "search_product")
    SEARCH_BUTTON = (By.ID, "submit_search")
    PRODUCT_NAME = (By.XPATH, "//h2[@class='product-name']")
    PRODUCT_CATEGORY = (By.XPATH, "//p[contains(text(),'Category')]")
    PRODUCT_PRICE = (By.XPATH, "//span[@class='price']")
    PRODUCT_AVAILABILITY = (By.XPATH, "//b[text()='Availability:']/following-sibling::span")
    PRODUCT_CONDITION = (By.XPATH, "//b[text()='Condition:']/following-sibling::span")
    PRODUCT_BRAND = (By.XPATH, "//b[text()='Brand:']/following-sibling::span")

    def click_products_button(self):
        self.do_click(self.PRODUCTS_HEADER)

    def is_products_list_visible(self):
        return self.is_element_visible(self.PRODUCTS_HEADER)

    def click_product_by_name(self, product_name):
        product_link = (By.XPATH, f"//a[contains(text(),'{product_name}')]")
        self.do_click(product_link)

    def get_page_header(self):
        return self.get_text(self.PRODUCTS_HEADER)

    def get_product_name(self):
        return self.get_text(self.PRODUCT_NAME)

    def get_product_category(self):
        return self.get_text(self.PRODUCT_CATEGORY)

    def get_product_price(self):
        return self.get_text(self.PRODUCT_PRICE)

    def get_product_availability(self):
        return self.get_text(self.PRODUCT_AVAILABILITY)

    def get_product_condition(self):
        return self.get_text(self.PRODUCT_CONDITION)

    def get_product_brand(self):
        return self.get_text(self.PRODUCT_BRAND)
    
    def search_product(self, product_name):
        search_box = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, "searchBox")))
        search_box.clear()
        search_box.send_keys(product_name)
        search_box.submit()
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, f"//div[contains(text(), '{product_name}')]")))

