from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class ContactUsPage(BasePage):
    NAME_LOCATOR = (By.NAME, "name")
    EMAIL_LOCATOR = (By.NAME, "email")
    SUBJECT_LOCATOR = (By.NAME, "subject")
    MESSAGE_LOCATOR = (By.NAME, "message")
    FILE_UPLOAD_LOCATOR = (By.NAME, "upload_file")
    SUBMIT_BUTTON_LOCATOR = (By.XPATH, "//*[@id='contact-us-form']/div[6]/input")
    SUCCESS_MESSAGE_LOCATOR = (By.XPATH, "//*[@id='contact-page']/div[2]/div[1]/div/div[2]")
    GET_IN_TOUCH_LOCATOR = (By.XPATH, "//h2[contains(text(), 'Get In Touch')]")
    OK_BUTTON_LOCATOR = (By.XPATH, "//button[text()='OK']")
    HOME_BUTTON_LOCATOR = (By.XPATH, "//a[@href='/']")
    
    def enter_contact_details(self, name, email, subject, message):
        self.enter_text(self.NAME_LOCATOR, name)
        self.enter_text(self.EMAIL_LOCATOR, email)
        self.enter_text(self.SUBJECT_LOCATOR, subject)
        self.enter_text(self.MESSAGE_LOCATOR, message)
        
    def upload(self, file_locator, file_path):
        file_input = self.find_web_element(file_locator)
        file_input.send_keys(file_path)
    
    def upload_file(self, file_path):
        self.upload(self.FILE_UPLOAD_LOCATOR, file_path)
    
    def click_submit(self):
        self.click(self.SUBMIT_BUTTON_LOCATOR)
    
    def click_ok(self):
        self.click(self.OK_BUTTON_LOCATOR)
    
    def click_home_button(self):
        self.click(self.HOME_BUTTON_LOCATOR)
    
    def is_get_in_touch_visible(self):
        return self.is_element_visible(self.GET_IN_TOUCH_LOCATOR)
    
    def is_success_message_visible(self):
        return self.is_element_visible(self.SUCCESS_MESSAGE_LOCATOR)
    
    
