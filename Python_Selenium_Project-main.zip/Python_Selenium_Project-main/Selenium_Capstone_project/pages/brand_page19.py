from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

class BrandProductsPage(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    BRANDS_SECTION = (By.XPATH, "//h2[normalize-space()='Brands']")
    FIRST_BRAND_NAME = (By.XPATH, "(//a[@href='/brand_products/Polo'])")
    BRAND_PRODUCTS_HEADER = (By.XPATH, "//h2[@class='title text-center']")
    SECOND_BRAND_NAME = (By.XPATH, "(//div[@class='brands-name']/ul/li/a)[2]")

    def _init_(self, driver):
        super()._init_(driver)

    def click_products_button(self):
        self.click(self.PRODUCTS_BUTTON)

    def verify_brands_visible(self):
        return self.is_element_visible(self.BRANDS_SECTION)

    def click_first_brand(self):
        element = self.driver.find_element(*self.FIRST_BRAND_NAME)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIRST_BRAND_NAME))
        ActionChains(self.driver).move_to_element(element).click(element).perform()

    def verify_brand_page_displayed(self):
        return self.is_element_visible(self.BRAND_PRODUCTS_HEADER)

    def click_second_brand(self):
        element = self.driver.find_element(*self.SECOND_BRAND_NAME)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.SECOND_BRAND_NAME))
        ActionChains(self.driver).move_to_element(element).click(element).perform()







