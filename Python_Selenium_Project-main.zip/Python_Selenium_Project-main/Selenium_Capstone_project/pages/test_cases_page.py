from selenium.webdriver.common.by import By 
from pages.base_page import BasePage 
import time

class VerifyTestCasePage(BasePage):
    TEST_CASES_BUTTON = (By.LINK_TEXT, "Test Cases")
    TEST_CASES_HEADER = (By.XPATH, '//*[@id="form"]/div/div[1]/div/h2/b')

    def verify_home_page_visible(self):
        return "Automation Exercise" in self.driver.title 
    

    def navigate_to_test_cases(self):
        self.driver.find_element(*self.TEST_CASES_BUTTON).click()
        time.sleep(2)
        
    def verify_test_cases_page(self):
        display_element = self.driver.find_element(*self.TEST_CASES_HEADER).is_displayed() 
        if display_element:
            print("Test Case Page is Exist...") 
        else:
            print("Not Exist") 
            
        return display_element



