from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage
import time

class OrderPage(BasePage):
    # Locators
    SIGNUP_LOGIN_BUTTON = (By.XPATH, "//u[normalize-space()='Register / Login']")
    EMAIL_LOCATOR = (By.NAME, "email")
    PASSWORD_LOCATOR = (By.NAME, "password")
    LOGIN_BUTTON_LOCATOR = (By.XPATH, "//button[text()='Login']")
    LOGGED_IN_AS_LOCATOR = (By.XPATH, "//b[normalize-space()='ABC']")
    VIEW_PRODUCT_LOCATOR = (By.XPATH, "//a[normalize-space()='View Product'][@href='/product_details/1']")
    QUANTITY_LOCATOR = (By.ID, "quantity")
    ADD_TO_CART_BUTTON = (By.XPATH, "//button[normalize-space()='Add to cart']")
    VIEW_CART_BUTTON_LOCATOR = (By.XPATH, "//u[normalize-space()='View Cart']")
    PROCEED_TO_CHECKOUT_BUTTON = (By.XPATH, "//a[normalize-space()='Proceed To Checkout']")
    #PROCEED_TO_CHECKOUT_BUTTON2 = (By.XPATH, "//a[normalize-space()='Proceed To Checkout']")

    CART_PAGE_DISPLAYED_LOCATOR = (By.XPATH, "//tr[@id='product-1']")
    COMMENT_TEXT_AREA_LOCATOR = (By.XPATH, "//textarea[@name='message']")
    PLACE_ORDER_BUTTON = (By.XPATH, "//a[normalize-space()='Place Order']")
    NAME_ON_CARD_LOCATOR = (By.NAME, "name_on_card")
    CARD_NUMBER_LOCATOR = (By.NAME, "card_number")
    CVC_LOCATOR = (By.NAME, "cvc")
    EXPIRATION_DATE_LOCATOR = (By.XPATH, '//*[@id="payment-form"]/div[3]/div[3]/input')
    PAY_AND_CONFIRM_BUTTON = (By.XPATH, "//button[@id='submit']")
    SUCCESS_MESSAGE_LOCATOR = (By.XPATH, '//*[@id="form"]/div/div/div/h2')
    EX_DATE = (By.XPATH, '//*[@id="payment-form"]/div[3]/div[2]/input')
    DELETE_ACCOUNT_BTN = (By.XPATH, "//a[normalize-space()='Delete Account']")
    DELETE_SUCCESS = (By.XPATH, "//b[normalize-space()='Account Deleted!']")
    END_CONTINUE = (By.XPATH, "//a[normalize-space()='Continue']")
    DOWNLOAD_INVOICE_BUTTON = (By.XPATH, "//a[normalize-space()='Download Invoice']")
    CONTINUE_BUTTON_AFTER_DOWNLOAD = (By.XPATH, "//a[normalize-space()='Continue']")
    ACCOUNT_CREATED_MESSAGE = (By.XPATH, "//h2[normalize-space()='ACCOUNT CREATED!']")
    CONTINUE_BUTTON = (By.XPATH, "//a[normalize-space()='Continue']")
    VIEW_CART_IN_HOME = (By.XPATH, "(//a[normalize-space()='Cart'])[1]")
    def click_signup_login_button(self):
        self.click(self.SIGNUP_LOGIN_BUTTON)

    def fill_login_form(self, email, password):
        self.enter_text(self.EMAIL_LOCATOR, email)
        time.sleep(2)
        self.enter_text(self.PASSWORD_LOCATOR, password)
        time.sleep(2)
        self.click(self.LOGIN_BUTTON_LOCATOR)
        time.sleep(2)

    def verify_logged_in_as(self, username):
        logged_in_as = self.driver.find_element(*self.LOGGED_IN_AS_LOCATOR)
        return username in logged_in_as.text

    def view_product(self):
        self.click(self.VIEW_PRODUCT_LOCATOR)
        time.sleep(2)

    def enter_quantity(self, quantity):
        quantity_field = self.driver.find_element(*self.QUANTITY_LOCATOR)
        quantity_field.clear()
        quantity_field.send_keys(quantity)
        time.sleep(2)

    def add_to_cart(self):
        self.click(self.ADD_TO_CART_BUTTON)
        time.sleep(2)

    def view_cart(self):
        self.click(self.VIEW_CART_BUTTON_LOCATOR)
        time.sleep(2)
        
    def home_view_cart(self):
        self.click(self.VIEW_CART_IN_HOME)
        
    def click_proceed_to_checkout_button(self):
      self.click(self.PROCEED_TO_CHECKOUT_BUTTON)
      time.sleep(2)

    """def cart(self): 
        self.click_button(self.VIEW_CART_IN_HOME) 
        time.sleep(2) 
        self.click_button(self.PROCEED_TO_CHECKOUT_BUTTON) 
        time.sleep(2)
"""
    def enter_description(self, description):
        self.enter_text(self.COMMENT_TEXT_AREA_LOCATOR, description)
        time.sleep(2)

    def click_place_order_button(self):
        self.click(self.PLACE_ORDER_BUTTON)

    def enter_payment_details(self, name, card_number, cvc, expiration_date, exdate):
        self.enter_text(self.NAME_ON_CARD_LOCATOR, name)
        time.sleep(1)
        self.enter_text(self.CARD_NUMBER_LOCATOR, card_number)
        time.sleep(1)
        self.enter_text(self.CVC_LOCATOR, cvc)
        time.sleep(1)
        self.enter_text(self.EX_DATE, exdate)
        time.sleep(1)
        self.enter_text(self.EXPIRATION_DATE_LOCATOR, expiration_date)
        time.sleep(1)

    def click_pay_and_confirm_button(self):
        self.click(self.PAY_AND_CONFIRM_BUTTON)

    def verify_success_message(self):
        return self.is_element_visible(self.SUCCESS_MESSAGE_LOCATOR)

    def click_download_invoice_button(self):
        self.click(self.DOWNLOAD_INVOICE_BUTTON)

    def verify_invoice_downloaded(self):
        """Verify that the invoice is downloaded successfully."""
        # Placeholder for actual invoice download verification logic
        return True  # Simulate that the invoice has been downloaded successfully

    def click_continue_button_after_download(self):
        self.click(self.CONTINUE_BUTTON_AFTER_DOWNLOAD)

    def delete_account(self):
        self.click(self.DELETE_ACCOUNT_BTN)

    def verify_account_deleted(self):
        return self.is_element_visible(self.DELETE_SUCCESS)

    def click_continue_button_after_delete(self):
        self.click(self.END_CONTINUE)

    def verify_account_created(self):
        return self.is_element_visible(self.ACCOUNT_CREATED_MESSAGE)

    def click_continue_button(self):
        self.click(self.CONTINUE_BUTTON)