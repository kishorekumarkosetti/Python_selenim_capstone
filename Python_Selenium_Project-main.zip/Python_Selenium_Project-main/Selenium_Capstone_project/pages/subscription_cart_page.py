from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class CartPage(BasePage):
    HOME_PAGE_INDICATOR = (By.XPATH, "//a[@href='/']")
    CART_BUTTON = (By.XPATH, "//a[@href='/view_cart']")
    SUBSCRIPTION_TEXT = (By.XPATH, "//h2[text()='Subscription']")
    EMAIL_INPUT = (By.ID, "susbscribe_email")
    SUBSCRIBE_BUTTON = (By.ID, "subscribe")
    SUCCESS_MESSAGE = (By.XPATH, "//div[contains(text(), 'You have been successfully subscribed!')]")

    def is_home_page_visible(self):
        return self.wait_for_element_to_be_visible(self.HOME_PAGE_INDICATOR, timeout=10)

    def click_cart_button(self):
        self.do_click(self.CART_BUTTON)

    def is_subscription_text_visible(self):
        return self.is_element_visible(self.SUBSCRIPTION_TEXT)

    def enter_email_in_subscription(self, email):
        self.do_send_keys(self.EMAIL_INPUT, email)
        self.do_click(self.SUBSCRIBE_BUTTON)

    def is_subscription_success_message_visible(self):
        return self.is_element_visible(self.SUCCESS_MESSAGE)
