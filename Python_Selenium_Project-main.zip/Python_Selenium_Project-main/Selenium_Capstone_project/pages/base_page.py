from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

class BasePage:
    def __init__(self, driver):
        self.driver = driver
    
    def visit(self, url):
        self.driver.get(url)
        self.driver.maximize_window()
        
    def find_web_element(self, locator):
        return self.driver.find_element(*locator)
    
    def enter_text(self, locator, text):
        element = self.find_web_element(locator)
        element.clear()  
        element.send_keys(text)
    
    def click(self, locator):
        element = self.find_web_element(locator)
        element.click()
        
    def select_option(self, locator, option_text):
        dropdown_element = self.find_web_element(locator)
        select = Select(dropdown_element)
        select.select_by_visible_text(option_text)

    def is_element_visible(self, locator):
        try:
            WebDriverWait(self.driver, 1).until(
                EC.visibility_of_element_located(locator)
            )
            return True
        except:
            return False

    def do_send_keys(self, locator, value, timeout=5):
        WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located(locator)).send_keys(value)
    
    def do_click(self, locator, timeout=5):
        try:
            WebDriverWait(self.driver, timeout).until( EC.element_to_be_clickable(locator)).click()
        except Exception as e:
            raise Exception(f"Failed to click on element with locator {locator}: {e}")
        
     
    def get_elements(self, locator, timeout=1):
        try:
          
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_all_elements_located(locator)
            )
            elements = self.driver.find_elements(*locator)

            print(f"Found {len(elements)} elements for locator: {locator}")
            
            return elements
        except Exception as e:
            raise Exception(f"Failed to locate elements with locator {locator}: {e}")

    
    def wait_for_element_to_be_visible(self, locator, timeout=10):
        return WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(locator),message=f"Element with locator {locator} not visible after {timeout} seconds")

    def is_all_products_header_visible(self, timeout=1):
        try:
            WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(self.all_products_header_locator))
            return True
        except Exception as e:
            print(f"Error verifying visibility of 'All Products' header: {e}")
            return False
    
    def is_all_products_header_visible(self, timeout=10):
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located(self.ALL_PRODUCTS_HEADER_LOCATOR)
            )
            return True
        except:
            return False
    
    def scroll_to_element(self, element):
        """Scroll to the specified element."""
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)