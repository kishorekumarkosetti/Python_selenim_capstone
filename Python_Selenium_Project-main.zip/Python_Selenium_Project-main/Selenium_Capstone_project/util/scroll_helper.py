from selenium.webdriver.common.by import By

class ScrollHelper:
    def __init__(self,driver):
        self.driver=driver
    
    def scroll_by_pixels(self,x,y):
     
        self.driver.execute_script(f"window.scrollBy({x},{y});")
    
    def scroll_to_bottom(self):
       
        self.driver.execute_script(f"window.scrollTo(0,document.body.scrollHeight);")
    
    def scroll_to_top(self):
        
        self.driver.execute_script(f"window.scrollTo(0,0);")
    
    def scroll_to_element(self,element):
        self.driver.execute_script("arguments[0].scrollIntoView();", element)



