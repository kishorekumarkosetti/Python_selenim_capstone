
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

class WaitHelper:
    def __init__(self,driver,timout=10):
        
        self.driver=driver
        self.wait=WebDriverWait(driver,timout)
    
    def wait_for_alert(self):
        
        return self.wait.until(EC.alert_is_present())

    def wait_for_element_visible(self, by_locator, locator):
     
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.visibility_of_element_located((by_locator, locator))
            )
        except TimeoutException:
            print(f"Timeout: Element with locator '{locator}' not visible after {self.timeout} seconds.")
            return None
        
    def wait_for_element_clickable(self, by_locator, locator):
      
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.element_to_be_clickable((by_locator, locator))
            )
        except TimeoutException:
            print(f"Timeout: Element with locator '{locator}' not clickable after {self.timeout} seconds.")
            return None
    def wait_for_presence_of_element(self, by_locator, locator):
     
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.presence_of_element_located((by_locator, locator))
            )
        except TimeoutException:
            print(f"Timeout: Element with locator '{locator}' not present in DOM after {self.timeout} seconds.")
            return None
    def wait_for_text_in_element(self, by_locator, locator, text):
       
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.text_to_be_present_in_element((by_locator, locator), text)
            )
        except TimeoutException:
            print(f"Timeout: Text '{text}' not found in element with locator '{locator}' after {self.timeout} seconds.")
            return False
        
    def wait_for_alert(self):
     
        try:
            return WebDriverWait(self.driver, self.timeout).until(EC.alert_is_present())
        except TimeoutException:
            print(f"Timeout: No alert appeared after {self.timeout} seconds.")
            return None