import csv

class CSVUtil:
    @staticmethod
    def read_data(file_path):
        data = []
        with open(file_path, newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                data.append(tuple(row.values())) 
        return data
