import time

def take_screenshot(driver, save_path="C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\screen_shots", filename_prefix="screenshot"):
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    filename = f"{save_path}/{filename_prefix}_{timestamp}.png"
    driver.save_screenshot(filename)
    print(f"Screenshot saved: {filename}")