class Config:
    BASE_URL="http://automationexercise.com"
    LOG_FILE="reports/logs/test_log.log"
    BROWSER_NAME="chrome"