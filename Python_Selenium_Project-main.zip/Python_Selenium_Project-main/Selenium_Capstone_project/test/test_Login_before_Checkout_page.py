import pytest
from pages.Login_before_Checkout_page import HomePage, SignupPage, ProductsPage, CartPage, CheckoutPage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestEndToEndFlow:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.signup_page = SignupPage(self.driver)
        self.products_page = ProductsPage(self.driver)
        self.cart_page = CartPage(self.driver)
        self.checkout_page = CheckoutPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    def test_end_to_end_flow(self):
        # Ensure the home page is loaded
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        print("Home page is successfully loaded.")

        # Click 'Signup / Login' button
        self.home_page.click_signup_login_button()

        # Fill all details in login page and click login
        self.signup_page.fill_login_form("abci123@gmail.com", "12345678")

        # Verify 'Logged in as username' at top
        assert self.signup_page.verify_logged_in_as("ABC"), "'Logged in as username' is not visible."

        # View product on Men T-shirt
        self.products_page.view_product()

        # Enter quantity
        self.products_page.enter_quantity(1)

        # Add to cart
        self.products_page.add_to_cart()

        # View cart
        self.products_page.view_cart()

        # Verify that cart page is displayed
        # Click Proceed To Checkout
        self.cart_page.click_proceed_to_checkout_button()

        # Enter description in comment text area and click 'Place Order'
        self.checkout_page.enter_description("Description text here ")
        self.checkout_page.click_place_order_button()

        # Enter payment details
        self.checkout_page.enter_payment_details("Mastercard", "1234567890123456", "123", "8" , "12/36")

        # Click 'Pay and Confirm Order' button
        self.checkout_page.click_pay_and_confirm_button()

        # Verify success message
        assert self.checkout_page.verify_success_message(), "'Congratulations! Your order has been confirmed!' message is not visible."

    def teardown_method(self):
        self.driver.quit()