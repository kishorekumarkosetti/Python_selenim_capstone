import pytest
from config.config import Config
from pages.home_page import HomePage
from pages.search_product_page import ProductsPage
from util.data_provider import DataProvider
from util.scroll_helper import ScrollHelper

@pytest.mark.usefixtures("init_driver")
class TestSearchProduct:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.products_page = ProductsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("product_name", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\search_product.csv"))
    def test_search_product(self, product_name):
        assert self.home_page.is_home_page_visible(), "Home page is not visible"

        self.home_page.click_products()
        assert self.products_page.is_all_products_header_visible(), "All Products page not visible"

        self.products_page.search_product(product_name[0]) 
        assert self.products_page.is_searched_products_header_visible(), "Searched Products header not visible"

        product_count = self.products_page.get_searched_products_count()
        assert product_count > 0, f"No products found for the search '{product_name[0]}'"
        assert self.products_page.is_searched_products_header_visible(), "Searched Products header not visible"

        product_count = self.products_page.get_searched_products_count()
        assert product_count > 0, f"No products found for the search '{product_name[0]}'"






