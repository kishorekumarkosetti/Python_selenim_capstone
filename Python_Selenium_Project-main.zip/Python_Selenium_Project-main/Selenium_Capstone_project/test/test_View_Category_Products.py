import pytest
from pages.home_page import HomePage
from pages.View_Category_Products import CategoryProductsPage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestViewCategoryProducts:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.category_products_page = CategoryProductsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    def test_view_category_products(self):
        # Ensure the home page is loaded
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        print("Home page is successfully loaded.")

        # Verify that categories are visible on left side bar
        assert self.category_products_page.verify_categories_visible(), "Categories are not visible on the left side bar."

        # Click on 'Women' category
        self.category_products_page.click_women_category()

        # Click on any category link under 'Women' category, for example: Dress
        self.category_products_page.click_women_category_dress()

        assert self.category_products_page.verify_category_page_displayed(), "Category page is not displayed or text 'WOMEN - DRESS PRODUCTS' is not found."

        self.category_products_page.click_men_category()
        self.category_products_page.click_men_subcategory()

        assert self.category_products_page.verify_men_category_page_displayed(), "Men category page is not displayed or text 'MEN - T-SHIRT PRODUCTS' is not found."

    def teardown_method(self):
        self.driver.quit()