import pytest
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from config.config import Config
from pages.Register_while_Checkout import PlaceOrderRegisterCheckoutPage
from util.scroll_helper import ScrollHelper
import time

@pytest.mark.usefixtures("init_driver")
class TestPlaceOrderRegisterCheckoutFlow:
    def test_place_order_register_checkout(self):
        page = PlaceOrderRegisterCheckoutPage(self.driver)
        scroll_helper = ScrollHelper(self.driver)
        page.visit(Config.BASE_URL)
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        page.click_products_button()

        page.add_to_cart()
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(page.VIEW_CART_BUTTON)).click()
        page.proceed_to_checkout()
        page.click_register_login()
        page.fill_signup_details(
            name="Naruto",
            email="naruto_uzumaki2@gmail.com",
            password="ramen123",
            day="10",
            month="October",
            year="1999",
            first_name="Naruto",
            last_name="Uzumaki",
            company="Ninja Way Inc.",
            address1="123 Konoha Street",
            address2="Apartment 7",
            country="United States",
            state="Kanagawa",
            city="Konoha",
            zipcode="123456",
            mobile="0987654321"
        )
        assert page.verify_account_created(), "Account creation failed."
        print("Account Created...!")
        page.click_continue_button()

        assert page.verify_login_username(), "User login verification failed."
        page.verify_cart_button()
        page.click_proceed_to_checkout_again()

        page.place_order()
        page.fill_payment_details(
            name_on_card="Test User",
            card_number="432156798398",
            cvc="123",
            exp_month="12/36",
            exp_year="2025"
        )

        assert page.verify_order_success(), "Order placement failed."
        print("Order placed successfully...!")
        page.delete_account()
        assert page.verify_account_deleted(), "Account deletion failed."
        print("Account deleted successfully...!")
