import pytest
from config.config import Config
from pages.home_page import HomePage
from pages.products_page import ProductsPage
from util.data_provider import DataProvider

@pytest.mark.usefixtures("init_driver")
class TestVerifyProductsAndDetails:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.products_page = ProductsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("product_name", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\products_data.csv"))
    def test_verify_all_products_and_product_detail_page(self, product_name):
        assert self.home_page.is_home_page_visible(), "Home page is not visible"

        self.products_page.click_products_button()
        assert self.products_page.is_all_products_page_visible(), "All Products page is not visible"

        assert self.products_page.is_products_list_visible(), "Products list is not visible"

        self.products_page.search_product(product_name[0])
        self.products_page.click_first_product_view()

        assert self.products_page.is_product_detail_page_visible(), "Product detail page is not visible"

        assert self.products_page.is_product_detail_visible(), f"Product details for '{product_name[0]}' are not visible"

