import pytest
from config.config import Config
from pages.subscription_data_page import SubscriptionPage
from util.data_provider import DataProvider
from util.scroll_helper import ScrollHelper

@pytest.mark.usefixtures("init_driver")
class TestVerifySubscription:
    def setup_method(self):
        self.home_page = SubscriptionPage(self.driver)
        self.scroll_helper = ScrollHelper(self.driver)

    @pytest.mark.parametrize("email", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\subscription_data.csv"))
    def test_verify_subscription(self, email):
    
        self.home_page.visit(Config.BASE_URL)

        assert self.home_page.is_home_page_visible(), "Home page is not visible"

       
        self.scroll_helper.scroll_to_bottom()

        assert self.home_page.is_subscription_text_visible(), "'SUBSCRIPTION' text not visible"

        self.home_page.enter_email_in_subscription(email)

        assert self.home_page.is_subscription_success_message_visible(), "Subscription success message not visible"
