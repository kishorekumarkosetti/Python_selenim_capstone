import pytest
from pages.home_page import HomePage
from pages.brand_page19 import BrandProductsPage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestViewCartBrandProducts:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.brand_products_page = BrandProductsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    def test_view_cart_brand_products(self):
 
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        print("Home page is successfully loaded.")

        self.brand_products_page.click_products_button()

        assert self.brand_products_page.verify_brands_visible(), "Brands are not visible on the left side bar."

        self.brand_products_page.click_first_brand()


        assert self.brand_products_page.verify_brand_page_displayed(), "Brand page is not displayed or brand products are not visible."

        self.brand_products_page.click_second_brand()

        assert self.brand_products_page.verify_brand_page_displayed(), "Second brand page is not displayed or brand products are not visible."

    def teardown_method(self):
        self.driver.quit()




