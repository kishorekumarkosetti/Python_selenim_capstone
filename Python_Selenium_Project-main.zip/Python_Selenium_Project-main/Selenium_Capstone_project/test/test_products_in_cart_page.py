import pytest
from pages.products_in_cart_page import HomePage
from config.config import Config
#from utils.take_screenshot import take_screenshot
from util.data_provider import DataProvider  # Assuming this utility exists

@pytest.mark.usefixtures("init_driver")
class TestAddProductsToCart:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize(
        "product_indices",
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\product_in_cart.csv")
    )
    def test_add_products_in_cart(self, product_indices):
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        print("Home page is successfully loaded.")

        self.home_page.click_products_button()
        print("Navigated to Products page.")

        self.home_page.hover_and_add_to_cart(int(product_indices[0]))
        print(f"First product (index {product_indices[0]}) added to cart.")

        self.home_page.click_continue_shopping()
        print("Clicked 'Continue Shopping'.")

    
        self.home_page.hover_and_add_to_cart(int(product_indices[1]))
        print(f"Second product (index {product_indices[1]}) added to cart.")

        self.home_page.click_view_cart()
        print("Navigated to View Cart page.")

        cart_products = self.home_page.get_cart_products()
        assert len(cart_products) == len(product_indices), (
            f"Expected {len(product_indices)} products in the cart, but found {len(cart_products)}."
        )
        print(f"Number of products in cart: {len(cart_products)}")

"""
       # Take a screenshot
        screenshot_path = take_screenshot(
            self.driver, save_path="screenshots", filename_prefix="adding_products_to_cart"
        )
        print(f"Screenshot taken: {screenshot_path}") """



