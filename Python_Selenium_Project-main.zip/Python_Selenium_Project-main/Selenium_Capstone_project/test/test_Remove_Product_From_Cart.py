import pytest
from config.config import Config
from pages.Remove_Product_From_Cart import RemoveProduct
from util.data_provider import DataProvider



@pytest.mark.usefixtures("init_driver")
class TestPlaceOrder:
    
    def setup_method(self):
        """Setup method initializes the page object and opens the website"""
        self.page =RemoveProduct(self.driver)
        self.page.visit(Config.BASE_URL) 

    @pytest.mark.parametrize(
        "username, password, first_name, last_name, email, phone, dob, company, address, city, state, zipcode",
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\Remove_Product_From_Cart.csv")
    )
    def test_place_order(self, username, password, first_name, last_name, email, phone, dob, company, address, city, state, zipcode):
            self.page.add_product_to_cart()  
            self.page.go_to_cart()  
            self.page.remove_product()






