from config.config import Config
from pages.Verify_Product_quantity import VerifyProductQuantityPage
from util.data_provider import DataProvider  
import pytest

@pytest.mark.usefixtures("init_driver")
class TestProductQuantity:
    def setup_method(self):
        self.page = VerifyProductQuantityPage(self.driver)
        self.page.visit(Config.BASE_URL)

    path = "C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\Verify_Product_Quality.csv"
    
    @pytest.mark.parametrize("product_name, quantity", DataProvider.get_data_from_csv(path))
    def test_product_quantity(self, product_name, quantity):

        assert "Automation Exercise" in self.driver.title, "Home page is not visible."

        self.page.click_view_product()

        assert self.page.is_element_visible(self.page.quantity_input), "Product detail page is not opened."

        self.page.increase_quantity(quantity)

        self.page.add_to_cart()

        self.page.click_view_cart_in_popup()

        quantity_in_cart = self.page.get_quantity_in_cart()
        if int(quantity_in_cart) > 4 :
            print(f"Expected quantity to be 4, but got {quantity_in_cart}")        
        else:
            print(f"Product '{product_name}' successfully added to cart with quantity {quantity}.")
    