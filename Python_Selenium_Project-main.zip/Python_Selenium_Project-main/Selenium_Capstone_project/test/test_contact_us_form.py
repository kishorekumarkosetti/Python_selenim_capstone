import pytest
import time
from util.data_provider import DataProvider
from config.config import Config
from pages.home_page import HomePage
from pages.contact_us_page import ContactUsPage

@pytest.mark.usefixtures("init_driver")
class TestContactUsForm:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.contact_us_page = ContactUsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("username, email, subject, message, file_path", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\contact_us_data.csv"))
    def test_contact_us_form(self, username, email, subject, message, file_path):
        self.home_page.click_contact_us()
        
    
        assert self.contact_us_page.is_get_in_touch_visible(), "GET IN TOUCH section not visible"
        time.sleep(2)
      
        self.contact_us_page.enter_contact_details(username, email, subject, message)
        time.sleep(2)
      
       
        self.contact_us_page.upload_file(file_path)
        time.sleep(2)
      
      
        self.contact_us_page.click_submit()
    
        alert = self.driver.switch_to.alert

  
        expected_alert_text = "Press OK to proceed!"
        assert alert.text == expected_alert_text, f"Unexpected alert text. Expected: '{expected_alert_text}', Got: '{alert.text}'"

        alert.accept() 
        assert self.contact_us_page.is_success_message_visible(), "Success message is not visible"
        self.contact_us_page.click_home_button()
        assert self.home_page.is_home_page_visible(), "Failed to navigate back to the home page"