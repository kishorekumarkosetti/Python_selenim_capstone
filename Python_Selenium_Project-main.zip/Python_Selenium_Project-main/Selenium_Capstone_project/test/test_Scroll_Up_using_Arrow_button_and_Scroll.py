import pytest
from pages.Scroll_Up_using_Arrow_button_and_Scroll import ScrollPage
from pages.home_page import HomePage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestScrollFunctionality:
    def test_scroll_functionality(self):
        home_page = HomePage(self.driver)
        scroll_page = ScrollPage(self.driver)

        home_page.visit(Config.BASE_URL)

        scroll_page.verify_home_page()

        scroll_page.scroll_down_to_bottom()

        scroll_page.verify_subscription_visible()

        scroll_page.click_arrow_button()

        scroll_page.verify_practice_website_text_visible()