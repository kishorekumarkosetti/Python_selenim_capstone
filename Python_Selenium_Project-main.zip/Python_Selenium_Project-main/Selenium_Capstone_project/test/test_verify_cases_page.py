from config.config import Config
from pages.test_cases_page  import VerifyTestCasePage
import pytest

@pytest.mark.usefixtures("init_driver")
class TestVerifyTestCasesPage:
    def setup_method(self):
        self.page = VerifyTestCasePage(self.driver) 
        self.page.visit(Config.BASE_URL)
    
    def test_testCasePage(self):
        assert self.page.verify_home_page_visible(), "Home page is not visible."
        self.page.navigate_to_test_cases()
        assert self.page.verify_test_cases_page(), "'Test Cases' page is not visible."

