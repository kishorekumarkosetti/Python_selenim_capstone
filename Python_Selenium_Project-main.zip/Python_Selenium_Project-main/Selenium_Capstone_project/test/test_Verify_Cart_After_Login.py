import pytest
from config.config import Config
from pages.Verify_Cart_After_Login import SearchAndCartPage

@pytest.mark.usefixtures("init_driver")
class TestSearchAndCartPage:

    def setup_method(self):
        self.page = SearchAndCartPage(self.driver)
        self.page.visit(Config.BASE_URL)

    @pytest.mark.parametrize(
        "search_term, email, password",
        [
            ("Men Tshirt", "abci123@gmail.com", "12345678"),
        ]
    )
    def test_search_and_cart(self, search_term, email, password):

        # Step 1: Click on the 'Products' button
        self.page.click_products_button()

        # Step 2: Verify user is navigated to ALL PRODUCTS page
        assert self.page.verify_all_products_page(), "User is not navigated to ALL PRODUCTS page."

        # Step 3: Search for a product
        self.page.search_for_product(search_term)

        # Step 4: Verify 'SEARCHED PRODUCTS' is visible
        assert self.page.verify_searched_products_visible(), "'SEARCHED PRODUCTS' is not visible."

        # Step 5: Verify all products related to search are visible
        assert self.page.verify_search_results(), "Search results are not visible."

        # Step 6: Add products to cart and handle popup
        self.page.add_search_results_to_cart_and_view_cart()

        # Step 7: Verify products in the cart
        assert self.page.verify_products_in_cart(), "Products are not visible in the cart."

        # Step 8: Log in
        self.page.click_login_signup()
        self.page.enter_login_details(email, password)
        self.page.submit_login()

        # Step 9: Verify products are still in the cart
        self.page.go_to_cart()
        assert self.page.verify_products_in_cart(), "Products are not visible in the cart after login."

        # Step 10: Remove all products from cart
        self.page.remove_all_products_from_cart()

        # Step 11: Verify the cart is empty
        assert self.page.verify_cart_empty(), "The cart is not empty."
