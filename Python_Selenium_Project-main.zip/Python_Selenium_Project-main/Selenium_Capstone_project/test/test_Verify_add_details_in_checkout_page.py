import pytest
from config.config import Config
from pages.Verify_add_details_in_checkout_page import OrderPage

@pytest.mark.usefixtures("init_driver")
class TestVerifyAddressDetailsInCheckout:
    def setup_method(self):
        self.order_page = OrderPage(self.driver)
        self.order_page.visit(Config.BASE_URL)

    def test_verify_address_details_in_checkout(self):
        # Step 1: Launch browser
        # This is done by the init_driver fixture

        # Step 2: Navigate to URL
        self.order_page.visit(Config.BASE_URL)

        # Step 3: Verify that home page is visible successfully
        assert "Automation Exercise" in self.driver.title

        # Step 4: Click 'Signup / Login' button
        self.order_page.click_signup_login_button()

        # Step 5: Fill all details in Signup and create account
        self.order_page.fill_signup_form(
            name="TestUser",
            email="kishorekumr12345@gmail.com",
            password="Password123",
            day="10",
            month="March",
            year="2000",
            first_name="Test",
            last_name="User",
            company="Test Company",
            address1="123 Test Street",
            address2="Suite 1",
            country="United States",
            state="Test State",
            city="Test City",
            zipcode="12345",
            mobile="1234567890"
        )

        # Step 6: Verify 'ACCOUNT CREATED!' and click 'Continue' button
        #assert self.order_page.verify_account_created(), "Account creation failed."
        self.order_page.click_continue_button()

        # Step 7: Verify 'Logged in as username' at top
        #assert self.order_page.verify_logged_in_as("TestUser"), "Login failed or username mismatch."

        # Step 8: Add products to cart
        self.order_page.view_product()
        self.order_page.enter_quantity(1)
        self.order_page.add_to_cart()

        # Step 9: Click 'Cart' button
        self.order_page.view_cart()

        # Step 10: Verify that cart page is displayed
        assert self.order_page.is_element_visible(OrderPage.CART_PAGE_DISPLAYED_LOCATOR), "Cart page is not displayed."

        # Step 11: Click Proceed To Checkout
        self.order_page.click_proceed_to_checkout_button()

        # Step 12: Verify that the delivery address and the billing address are the same as the address filled at the time of registration
        delivery_address = self.order_page.get_delivery_address()
        billing_address = self.order_page.get_billing_address()
        #assert delivery_address == billing_address, "Delivery and billing addresses do not match."

    def teardown_method(self):
        self.driver.quit()




















