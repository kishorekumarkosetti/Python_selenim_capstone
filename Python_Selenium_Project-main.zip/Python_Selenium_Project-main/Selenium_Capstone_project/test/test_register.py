import pytest
from config.config import Config
from pages.home_page import HomePage
from pages.registration_page import SignUpPage
import time
from util.data_provider import DataProvider
from util.screen_shot import take_screenshot

@pytest.mark.usefixtures("init_driver")
class TestRegisterUser:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.signup_page = SignUpPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("username, password, first_name, last_name, email, phone, dob, company, address, city, state, zipcode", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\user_data.csv"))
    def test_register_user_csv(self, username, password, first_name, last_name, email, phone, dob, company, address, city, state, zipcode):
        self.home_page.click_signup_login()
        self.signup_page.enter_signup_details(username, email)
        self.signup_page.enter_account_information("Mr", password, "3", "March", "2000") 
        self.signup_page.enter_address_details(first_name, last_name, company, address, city, state, zipcode, phone)
        self.signup_page.click_create_account()
        self.signup_page.click_continue()
        assert self.signup_page.is_logged_in_as()
        self.signup_page.click_delete_account()
        self.signup_page.click_continue()
        #take_screenshot(self.driver, filename_prefix="register_user_success")
        #time.sleep(2)
