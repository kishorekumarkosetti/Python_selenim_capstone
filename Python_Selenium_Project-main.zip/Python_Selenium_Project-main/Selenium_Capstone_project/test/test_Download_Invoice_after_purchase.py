import pytest
from pages.Download_Invoice_after_purchase import OrderPage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestDownloadInvoiceAfterPurchase:
    def setup_method(self):
        self.order_page = OrderPage(self.driver)
        self.order_page.visit(Config.BASE_URL)

    def test_download_invoice_after_purchase(self):
        
        assert "Automation Exercise" in self.driver.title

        # Step 4: Add products to cart
        self.order_page.view_product()
        self.order_page.enter_quantity(1)
        self.order_page.add_to_cart()

        # Step 5: Click 'Cart' button
        self.order_page.view_cart()

        # Step 6: Verify that cart page is displayed
        assert self.order_page.is_element_visible(OrderPage.CART_PAGE_DISPLAYED_LOCATOR), "Cart page is not displayed."

        # Step 7: Click Proceed To Checkout
        self.order_page.click_proceed_to_checkout_button()

        # Step 8: Click 'Register / Login' button
        self.order_page.click_signup_login_button()

        # Step 9: Fill all details in Signup and create account
        self.order_page.fill_login_form(
            email="abci123@gmail.com",
            password="12345678"
        )

        # Step 10: Verify 'ACCOUNT CREATED!' and click 'Continue' button
        #assert self.order_page.verify_account_created(), "Account creation failed."
        #self.order_page.click_continue_button()

        # Step 11: Verify 'Logged in as username' at top
        #assert self.order_page.verify_logged_in_as("ABC"), "Login failed or username mismatch."
        self.order_page.home_view_cart()
        self.order_page.click_proceed_to_checkout_button()

        # Step 12: Click 'Cart' button
        #self.order_page.view_cart()
        # Step 13: Click 'Proceed To Checkout' button
        #self.order_page.click_proceed_to_checkout_button()

        # Step 14: Verify Address Details and Review Your Order
        # This step is implicitly verified by navigating to the checkout page 
        #self.order_page.view_product()
        #self.order_page.enter_quantity(1)
        #self.order_page.add_to_cart()
        #self.order_page.view_cart()

        # Step 15: Enter description in comment text area and click 'Place Order' 
        self.order_page.enter_description("Please deliver between 9 AM and 5 PM")
        self.order_page.click_place_order_button()

        # Step 16: Enter payment details: Name on Card, Card Number, CVC, Expiration date
        self.order_page.enter_payment_details(
            name="ABC",
            card_number="1234567812345678",
            cvc="123",
            expiration_date="12",
            exdate="2026"
        )

        # Step 17: Click 'Pay and Confirm Order' button
        self.order_page.click_pay_and_confirm_button()

        # Step 18: Verify success message 'Congratulations! Your order has been confirmed!'
        assert self.order_page.verify_success_message(), "Order confirmation failed."

        # Step 19: Click 'Download Invoice' button and verify invoice is downloaded successfully
        self.order_page.click_download_invoice_button()
        assert self.order_page.verify_invoice_downloaded(), "Invoice download failed."

        # Step 20: Click 'Continue' button
        self.order_page.click_continue_button_after_download()

        # Step 21: Click 'Delete Account' button
        #self.order_page.delete_account()

        # Step 22: Verify 'ACCOUNT DELETED!' and click 'Continue' button
        #assert self.order_page.verify_account_deleted(), "Account deletion failed."
        #self.order_page.click_continue_button_after_delete()

    def teardown_method(self):
        self.driver.quit()