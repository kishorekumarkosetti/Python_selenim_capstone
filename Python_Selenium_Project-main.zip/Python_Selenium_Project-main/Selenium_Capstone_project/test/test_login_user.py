import pytest
from util.data_provider import DataProvider
from pages.login_page import LoginPage
from config.config import Config
from pages.home_page import HomePage

@pytest.mark.usefixtures("init_driver")
class TestLoginUser:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.login_page = LoginPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("email, password", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\CAPSTONE_PROJECT(ALL)\\Selenium_Capstone_project\\data\\login_data.csv"))
    def test_login_user_csv(self, email, password):
        self.home_page.click_signup_login()
        self.login_page.enter_login_details(email, password)
        self.login_page.click_login()
        assert self.login_page.is_logged_in_as()
