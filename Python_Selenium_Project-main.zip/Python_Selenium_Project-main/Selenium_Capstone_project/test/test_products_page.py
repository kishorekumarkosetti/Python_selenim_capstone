import pytest
from config.config import Config
from pages.home_page import HomePage
from pages.products_page import ProductsPage
from util.data_provider import DataProvider

@pytest.mark.usefixtures("init_driver")
class TestVerifyProductsAndDetails:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.products_page = ProductsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    @pytest.mark.parametrize("button_name, page_header, product_name, category, price, availability, condition, brand", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\products_data.csv"))
    def test_verify_all_products_and_product_detail_page(self, button_name, page_header, product_name, category, price, availability, condition, brand):

        assert self.home_page.is_home_page_visible(), "Home page is not visible"


        self.products_page.click_products_button()
        assert self.products_page.get_page_header() == page_header, f"Expected page header '{page_header}' but got '{self.products_page.get_page_header()}'"

        assert self.products_page.is_products_list_visible(), "Products list is not visible"

        self.products_page.search_product(product_name)
        self.products_page.click_product_by_name(product_name)

        assert self.products_page.get_product_name() == product_name, f"Expected product name '{product_name}' but got '{self.products_page.get_product_name()}'"
        assert self.products_page.get_product_category() == category, f"Expected category '{category}' but got '{self.products_page.get_product_category()}'"
        assert self.products_page.get_product_price() == price, f"Expected price '{price}' but got '{self.products_page.get_product_price()}'"
        assert self.products_page.get_product_availability() == availability, f"Expected availability '{availability}' but got '{self.products_page.get_product_availability()}'"
        assert self.products_page.get_product_condition() == condition, f"Expected condition '{condition}' but got '{self.products_page.get_product_condition()}'"
        assert self.products_page.get_product_brand() == brand, f"Expected brand '{brand}' but got '{self.products_page.get_product_brand()}'"



