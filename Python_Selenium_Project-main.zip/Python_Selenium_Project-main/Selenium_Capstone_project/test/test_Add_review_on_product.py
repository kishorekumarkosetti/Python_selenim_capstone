import pytest
from pages.home_page import HomePage
from pages.Add_review_on_product_page import AddReviewPage
from config.config import Config
from util.data_provider import DataProvider

@pytest.mark.usefixtures("init_driver")
class TestAddReviewOnProduct:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.add_review_page = AddReviewPage(self.driver)
        self.home_page.visit(Config.BASE_URL)
        

    path = ("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\Add_review_on_product.csv")
    @pytest.mark.parametrize("name, email, review", DataProvider.get_data_from_csv(path))
    def test_add_review_on_product(self, name, email, review):
        # Ensure the home page is loaded
        actual_title = self.driver.title
        print(f"Actual home page title: {actual_title}")
        assert "Automation Exercise" in actual_title, "Home page title does not match."
        print("Home page is successfully loaded.")

        # Click 'Products' button
        self.add_review_page.click_products_button()

        # Verify user is navigated to ALL PRODUCTS page successfully
        assert self.add_review_page.verify_all_products_page(), "ALL PRODUCTS page is not displayed."

        # Click on 'View Product' button
        self.add_review_page.click_view_product()

        # Verify 'Write Your Review' is visible
        assert self.add_review_page.verify_write_review_visible(), "'Write Your Review' is not visible."

        # Enter name, email and review
        self.add_review_page.enter_review_details(name, email, review)

        # Click 'Submit' button
        self.add_review_page.click_submit_button()

        # Verify success message 'Thank you for your review.'
        assert self.add_review_page.verify_success_message(), "Review submission success message not displayed."
        print("Thank you for your review message displayed successfully")

    def teardown_method(self):
         self.driver.quit()