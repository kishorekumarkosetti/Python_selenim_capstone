import pytest
from config.config import Config
from pages.subscription_cart_page import CartPage
from util.data_provider import DataProvider
from util.scroll_helper import ScrollHelper
from util.screen_shot import take_screenshot
import time

@pytest.mark.usefixtures("init_driver")
class TestVerifySubscriptionInCart:
    def setup_method(self):
        self.cart_page = CartPage(self.driver)
        self.scroll_helper = ScrollHelper(self.driver)

    @pytest.mark.parametrize("email", 
        DataProvider.get_data_from_csv("C:\\Users\\KISHORE KUMAR\\OneDrive\\Pictures\\Documents\\Selenium_Capstone_project\\data\\subscription_cart_data.csv"))
    def test_verify_subscription_in_cart(self, email):
     
        self.cart_page.visit(Config.BASE_URL)

        assert self.cart_page.is_home_page_visible(), "Home page is not visible"
        take_screenshot(self.driver, filename_prefix="Home page is visible")
        time.sleep(2)

        self.cart_page.click_cart_button()

        self.scroll_helper.scroll_to_bottom()

        assert self.cart_page.is_subscription_text_visible(), "'SUBSCRIPTION' text not visible"
        take_screenshot(self.driver, filename_prefix="SUBSCRIPTION'_text_visible")
        time.sleep(2)

        self.cart_page.enter_email_in_subscription(email)

        assert self.cart_page.is_subscription_success_message_visible(), "Subscription success message not visible"
