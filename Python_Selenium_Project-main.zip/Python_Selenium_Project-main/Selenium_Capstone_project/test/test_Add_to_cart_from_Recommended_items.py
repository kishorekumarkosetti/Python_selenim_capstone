import pytest
from pages.home_page import HomePage
from pages.Add_to_cart_from_Recommended_items import RecommendedItemsPage
from config.config import Config

@pytest.mark.usefixtures("init_driver")
class TestAddToCartFromRecommendedItems:
    def setup_method(self):
        self.home_page = HomePage(self.driver)
        self.recommended_items_page = RecommendedItemsPage(self.driver)
        self.home_page.visit(Config.BASE_URL)

    def test_add_to_cart_from_recommended_items(self):
        assert "Automation Exercise" in self.driver.title, "Home page title does not match."
        print("Home page is successfully loaded.")

        self.recommended_items_page.scroll_to_recommended_items()

        assert self.recommended_items_page.verify_recommended_items_visible(), "'RECOMMENDED ITEMS' are not visible."

        self.recommended_items_page.add_recommended_item_to_cart()

        self.recommended_items_page.click_view_cart_button()

        assert self.recommended_items_page.verify_product_in_cart(), "Product is not displayed in the cart page."
        print("Product is displayed in the cart page successfully.")

    def teardown_method(self):
        self.driver.quit()